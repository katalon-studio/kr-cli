import {StateMachine} from "./service/state-machine.js";
import {addOnboardingSampleData} from "./service/onboarding-sample-data.js";
import {TourService} from "./service/tour-service.js";
import {stateMapping} from "./service/state-mapping.js";
import {initialStateMachineDefinition} from "./service/essential-product-tours-state-machine.js";

function isObjectEmpty(obj){
    return obj &&
        Object.keys(obj).length === 0 &&
        obj.constructor === Object
}

async function isUserFirstTimeUsing() {
    let isFinnish = false;
    let isUpdate = false;
    const finnishOnboarding = await browser.storage.local.get("finnishOnboarding");
    let tracking = await browser.storage.local.get("tracking");
    if (!isObjectEmpty(finnishOnboarding)) {
        isFinnish = true;
    }
    if (!isObjectEmpty(tracking)){
        isUpdate = tracking.isUpdated ?? false;
    }
    return !(isFinnish || isUpdate);

}

export function startEssentialProductTours(forExistingUser) {
    let machine = new StateMachine(initialStateMachineDefinition);
    let tourService = new TourService(machine, stateMapping, forExistingUser);
    machine.addSubscriber(tourService);
    machine.transit(machine.currentState, "dialog");
}

//need to wait for document to finish loading
//since sample data is only loaded when document has finish loading

isUserFirstTimeUsing().then((result) => {
    if (result) {
        $((_) => {
            addOnboardingSampleData().then((value) =>
                startEssentialProductTours(false)
            );
        });
    }
});
