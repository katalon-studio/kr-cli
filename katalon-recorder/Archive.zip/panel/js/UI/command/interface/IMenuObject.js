import { Interface } from "./Interface.js";

export const IMenuObject = new Interface("MenuObject", ["show"])