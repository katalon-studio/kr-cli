import { Interface } from "./Interface.js";

export const IComposite = new Interface("Composite", ["add", "remove", "getChild"]);