import { Interface } from "./Interface.js";

const ICommand = new Interface("ICommand", ["execute"]);

export { ICommand };