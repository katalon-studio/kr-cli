let htmlWhatsnews = `
<style>
    .whats-new-text {
        font-family: "Helvetica Neue", Helvetica, Arial, Verdana, sans-serif;
        font-size: 13px;
    }
</style>
<div class='whats-new-text'>
<h3>You're using Katalon Recorder 5.4.5</h3>
<p>In this update, we have: </p>
<ul>
    <li><b>Improved</b> the registration process.</li>
</ul>
</div>
`;

function displayWhatsNewDialog() {
  let newsDialog = $("<div></div>")
    .html(htmlWhatsnews)
    .dialog({
      title: `Everything is up to date`,
      resizable: true,
      height: "auto",
      width: "400",
      modal: true,
      buttons: {
        "Release note": () => {
          window.open(
            "https://docs.katalon.com/katalon-recorder/docs/release-notes.html"
          );
        },
        Close: function () {
          $(this).remove();
        },
      },
    });
  $("#close").click(() => {
    $(newsDialog).dialog("close");
  });
}

$(() => {
  chrome.storage.local.get("tracking", function (result) {
    if (result.tracking) {
      if (result.tracking.isUpdated) {
        chrome.storage.local.remove("tracking");
        displayWhatsNewDialog();
      }
    }
  });
});
