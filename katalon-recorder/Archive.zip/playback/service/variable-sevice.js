import { logger } from "./log-service.js";

const convertVariableToString = (variable) => {
  let originalVariable = variable;
  let frontIndex = variable.indexOf("${");
  let newStr = "";
  while (frontIndex !== -1) {
    let prefix = variable.substring(0, frontIndex);
    let suffix = variable.substring(frontIndex);
    let tailIndex = suffix.indexOf("}");
    if (tailIndex >= 0) {
      let suffix_front = suffix.substring(0, tailIndex + 1);
      let suffix_tail = suffix.substring(tailIndex + 1);
      newStr += prefix + xlateArgument(suffix_front);
      variable = suffix_tail;
      frontIndex = variable.indexOf("${");
    } else {
      // e.g. ${document https://forum.katalon.com/discussion/6083
      frontIndex = -1;
    }
  }
  let expanded = newStr + variable;
  logger.info("Expand variable '" + originalVariable + "' into '" + expanded + "'");
  return expanded;
}

function xlateArgument(value) {

  var mergedVars = {};

  value = value.replace(/^\s+/, '');
  value = value.replace(/\s+$/, '');
  var r;
  var r2;
  var parts = [];
  if ((r = /\$\{/.exec(value))) {
    var regexp = /\$\{(.*?)\}/g;
    var lastIndex = 0;
    while (r2 = regexp.exec(value)) {
      if (mergedVars[r2[1]] !== undefined) {
        if (r2.index - lastIndex > 0) {
          parts.push(string(value.substring(lastIndex, r2.index)));
        }
        parts.push(mergedVars[r2[1]]);
        lastIndex = regexp.lastIndex;
      } else if (r2[1] == "nbsp") {
        if (r2.index - lastIndex > 0) {
          parts.push(mergedVars[string(value.substring(lastIndex, r2.index))]);
        }
        parts.push(nonBreakingSpace());
        lastIndex = regexp.lastIndex;
      }
    }
    if (lastIndex < value.length) {
      parts.push(string(value.substring(lastIndex, value.length)));
    }
    return parts.join("");
  } else {
    return string(value);
  }
}

function string(value) {
  if (value != null) {
    value = value.replace(/\\/g, '\\\\');
    value = value.replace(/\"/g, '\\"');
    value = value.replace(/\r/g, '\\r');
    value = value.replace(/\n/g, '\\n');
    return value;
  } else {
    return '';
  }
}

export { convertVariableToString }