function getTestCaseName(testSteps) {
  let tdHTML = testSteps.slice(0, 1)[0].match(/<td[\s\S]*?<\/td>/gi)[0];
  let tr = document.createElement("tr");
  tr.innerHTML = tdHTML;
  return tr.innerText;
}

function getTestSuiteName(test_suite) {
  let testSuiteHTML = test_suite.match(/<title[\s\S]*?<\/title>/gi);
  let head = document.createElement("head");
  head.innerHTML = testSuiteHTML;
  return head.innerText;
}

function readSuiteFromString(test_suite) {
  let testSuiteName = getTestSuiteName(test_suite);
  let testCases = test_suite.match(/<table[\s\S]*?<\/table>/gi);
  testCases = testCases.map(testCase => {
    let testSteps = testCase.match(/<tr[\s\S]*?<\/tr>/gi);
    let testCaseName = getTestCaseName(testSteps);
    return {
      testCaseName: testCaseName,
      testCaseHTML: testSteps.slice(1).join("")
    }
  });
  return { testCases, testSuiteName };
}

export { readSuiteFromString }