var recorder;

const socket = io.connect('http://localhost:3500');

socket.on("sendHtml", function(data) {
    console.log(data.datafiles)
    let html = data.data;
    if (/\s/g.test(data.data)) {
        html = html.replace(/\s/g, '');
    }
    if (data.datafiles) {
        executtionTestSuite(html, data.datafiles);
    } else {
        executtionTestSuite(html);
    }
});

const executtionTestSuite = async function(html, datafiles) {
    let loadSettingData = await
    import ("../panel/js/background/load-setting-data.js");
    await loadSettingData.loadSettingData();
    let recorderModule = await
    import ("../panel/js/background/recorder.js");
    recorder = new recorderModule.BackgroundRecorder();
    let dataServiceModule = await
    import ("./service/data-service.js");
    let dataService = new dataServiceModule.DataService();

    if (datafiles) {
        dataService.setDataFiles(datafiles);
    }
    //parse data from HTML
    let parser = await
    import ("./service/parser-service.js");
    let testSuiteData = parser.readSuiteFromString(html);
    let testSuiteName = testSuiteData["testSuiteName"];
    let testCaseNames = testSuiteData["testCases"].map(testCase => testCase["testCaseName"])
    socket.emit('infoTestSuite', {
        testSuite: testSuiteName,
        testCases: testCaseNames
    });
    //run test suite
    let actions = await
    import ("./service/play-actions-service.js");
    actions.setDataService(dataService);
    actions.setTestSuiteData(testSuiteData);
    actions.playSuiteAction();
};