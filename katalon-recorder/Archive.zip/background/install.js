// KAT-BEGIN show docs on install or upgrade from 1.0
chrome.runtime.onInstalled.addListener(function(details) {
    if (details.reason === 'install') {
        chrome.tabs.create({
            url: 'https://www.katalon.com/sign-up/?utm_source=browser%20store&utm_campaign=installed%20KR'
        });
        segment().then(service => service.trackingInstallApp());

    } else if (details.reason === 'update') {
        browser.storage.local.set({
            tracking: {
                isUpdated: true
            }
        });
        notificationUpdate("Katalon Recorder has been updated", "Check out new bug fixes and feature enhancements!")
    }

});

chrome.runtime.onMessage.addListener(function(message) {
    chrome.storage.local.get('segment', function(result) {
        if (result.segment) {
            let segment = result.segment;
            chrome.runtime.setUninstallURL(`${chrome.runtime.getManifest().segment_url}/segment-kr/tracking?userId=${segment.userId || ''}&user=${encodeURI(segment.user) || ''}`);
        } else {
            chrome.runtime.setUninstallURL(`${chrome.runtime.getManifest().segment_url}/segment-kr/tracking`);
        }
    });
});

// KAT-END

async function segment() {
    const segmentSer = await
    import ('../panel/js/tracking/segment-tracking-service.js');
    return segmentSer;
}


const notify = "Katalon-update";

function notificationUpdate(title, content) {
    browser.notifications.create(notify, {
        "type": "basic",
        "iconUrl": "/katalon/images/branding/branding_48.png",
        "title": title,
        "message": content
    });

    setTimeout(function() {
        browser.notifications.clear(notify);
    }, 5000);
}