katalonServerPort = '59844'
katalonOnOffStatus = true
spy_captureObjectHotKey = {"keyCode":192,"useAltKey":true,"useShiftKey":false,"useCtrlKey":false,"useMetaKey":false};
spy_loadDomMapHotKey = {"keyCode":192,"useAltKey":true,"useShiftKey":false,"useCtrlKey":true,"useMetaKey":false};
