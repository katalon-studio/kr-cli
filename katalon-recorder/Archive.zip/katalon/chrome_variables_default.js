// This file contains default variables for Object spy chrome extensions
// To change variables, edit chrome_variables_init.js before starting extension
katalonServerPortForFirefox = "50001"
katalonServerPortForChrome= "50000"
katalonOnOffStatus = false
