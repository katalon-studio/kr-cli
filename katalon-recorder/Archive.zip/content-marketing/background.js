const socket = io.connect('http://localhost:3500');
console.log("hello")

socket.on("sendHtml", function(data) {
    console.log(data)
});

socket.emit("logger")